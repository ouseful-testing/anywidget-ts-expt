function i(r,n){for(let s of r.split(`
`))if(s[0]===":"&&s.substr(7,2)==="00"){let o=parseInt(s.substr(1,2),16),e=parseInt(s.substr(3,4),16);for(let t=0;t<o;t++)n[e+t]=parseInt(s.substr(9+t*2,2),16)}}export{i as loadHex};
